-- Création de la base de données
CREATE DATABASE IF NOT EXISTS RestaurantManagement;
USE RestaurantManagement;

-- Table Restaurant
CREATE TABLE Restaurant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    adresse VARCHAR(255) NOT NULL
);

-- Table Salle
CREATE TABLE Salle (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    nom VARCHAR(100) NOT NULL,
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(id)
);

-- Table Carré
CREATE TABLE Carre (
    id INT AUTO_INCREMENT PRIMARY KEY,
    salle_id INT NOT NULL,
    FOREIGN KEY (salle_id) REFERENCES Salle(id)
);

-- Table Rang
CREATE TABLE Rang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    carre_id INT NOT NULL,
    FOREIGN KEY (carre_id) REFERENCES Carre(id)
);

-- Table Table
CREATE TABLE RestaurantTable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rang_id INT NOT NULL,
    numero INT NOT NULL,
    capacite INT NOT NULL,
    FOREIGN KEY (rang_id) REFERENCES Rang(id)
);

-- Table Poste
CREATE TABLE Poste (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    description TEXT
);

-- Table Employé
CREATE TABLE Employe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    poste_id INT NOT NULL,
    salaire DECIMAL(10, 2),
    restaurant_id INT NOT NULL,
    FOREIGN KEY (poste_id) REFERENCES Poste(id),
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(id)
);

-- Table Client
CREATE TABLE Client (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    nombre_personnes INT NOT NULL
);

-- Table Commande
CREATE TABLE Commande (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATETIME NOT NULL,
    statut ENUM('en attente', 'en cours', 'terminé') NOT NULL,
    client_id INT NOT NULL,
    table_id INT NOT NULL,
    FOREIGN KEY (client_id) REFERENCES Client(id),
    FOREIGN KEY (table_id) REFERENCES RestaurantTable(id)
);

-- Table Recette
CREATE TABLE Recette (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    temps_preparation INT,
    temps_cuisson INT,
    temps_pause INT
);

-- Table Étape
CREATE TABLE Etape (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recette_id INT NOT NULL,
    ordre INT NOT NULL,
    description TEXT,
    temps_estime INT,
    FOREIGN KEY (recette_id) REFERENCES Recette(id)
);

-- Table Stock
CREATE TABLE Stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    quantite INT NOT NULL,
    type_stockage ENUM('frais', 'surgelé', 'réserve') NOT NULL
);

-- Table Matériel
CREATE TABLE Materiel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    type ENUM('assiette', 'verre', 'poêle', 'autre') NOT NULL,
    quantite INT NOT NULL,
    etat ENUM('disponible', 'utilisé', 'à laver') NOT NULL
);

-- Table Ustensile
CREATE TABLE Ustensile (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    quantite_disponible INT NOT NULL
);

-- Table Tâche
CREATE TABLE Tache (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    temps_estime INT
);

-- Table Tâche_Employé (relation N:M)
CREATE TABLE Tache_Employe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employe_id INT NOT NULL,
    tache_id INT NOT NULL,
    temps_debut DATETIME,
    temps_fin DATETIME,
    FOREIGN KEY (employe_id) REFERENCES Employe(id),
    FOREIGN KEY (tache_id) REFERENCES Tache(id)
);

-- Table Salle_Materiel (relation N:M)
CREATE TABLE Salle_Materiel (
    salle_id INT NOT NULL,
    materiel_id INT NOT NULL,
    PRIMARY KEY (salle_id, materiel_id),
    FOREIGN KEY (salle_id) REFERENCES Salle(id),
    FOREIGN KEY (materiel_id) REFERENCES Materiel(id)
);

-- Table Recette_Materiel (relation N:M)
CREATE TABLE Recette_Materiel (
    recette_id INT NOT NULL,
    materiel_id INT NOT NULL,
    PRIMARY KEY (recette_id, materiel_id),
    FOREIGN KEY (recette_id) REFERENCES Recette(id),
    FOREIGN KEY (materiel_id) REFERENCES Materiel(id)
);

-- Table Commande_Materiel (relation N:M)
CREATE TABLE Commande_Materiel (
    commande_id INT NOT NULL,
    materiel_id INT NOT NULL,
    PRIMARY KEY (commande_id, materiel_id),
    FOREIGN KEY (commande_id) REFERENCES Commande(id),
    FOREIGN KEY (materiel_id) REFERENCES Materiel(id)
);

